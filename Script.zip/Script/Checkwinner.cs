using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Checkwinner : MonoBehaviour

        
{
    public static Checkwinner instance;

    public Camera defaultCamera; 
    public bool isWinner = false;
    public Transform target;



    private void Awake()
    {
        instance = this;
    }
    // Start is called before the first frame update
    void Start()
    {

        
    }

    // Update is called once per frame
    void Update()
    {
       
        
    }
    private void LateUpdate()
    {
        
    }
    private void OnTriggerStay(Collider other)
    {
        if (other.CompareTag("Player") && PlayerController.instance) 
        {
            isWinner = true;
        }
    }
}
