using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CheckDead : MonoBehaviour


{
    public static CheckDead instance;

    public Camera defaultCamera;
    public bool youDead= false;
    public Transform target;
    

    private void Awake()
    {
        instance = this;
    }
    // Start is called before the first frame update
    void Start()
    {
        

    }

    // Update is called once per frame
    void Update()
    {
      

    }
    private void LateUpdate()
    {
        
    }
    private void OnTriggerStay(Collider other)
    {
        if (other.CompareTag("Player") && PlayerController.instance.groundedPlayer)
        {
            youDead = true;
        }
    }
}
