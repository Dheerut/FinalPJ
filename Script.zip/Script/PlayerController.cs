using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    private CharacterController charecterController;
    [SerializeField] private float playerSpeed = 5f;
    [SerializeField] private Camera followCamera;

    [SerializeField] private float rotationSpeed = 10f;

    private Vector3 playerVelocity;
    [SerializeField] private float gravityValue = -13f;

    public bool groundedPlayer;
    [SerializeField] private float jumpHeight = 2.5f;

    public Animator animator;

    public bool isDead;

//    public ParticleSystem damageParticle;

    public static PlayerController instance;
    private void Awake()
    {
        instance = this;
    }
    // Start is called before the first frame update
    void Start()
    {
        charecterController = GetComponent<CharacterController>();
        animator = GetComponentInChildren<Animator>();
    }

    //Update is called once per frame
    void Update()
    {
        switch (Checkwinner.instance.isWinner || isDead)
        {
            case true:
                animator.SetBool("Victory", Checkwinner.instance.isWinner);
                fixGravityWhenPlayerDead();
                if (isDead)
                    animator.SetBool("Dead", true);
                break;
            case false:
                Movement();
                break;
        }
        Movement();
    }

    void Movement()
    {
        groundedPlayer = charecterController.isGrounded;
        if (charecterController.isGrounded && playerVelocity.y < -2f)
        {
            playerVelocity.y = -1f;
        }
        float horizontalInput = Input.GetAxis("Horizontal");
        float verticalInput = Input.GetAxis("Vertical");

        Vector3 movementInput = Quaternion.Euler(0, followCamera.transform.eulerAngles.y, 0)
                                * new Vector3(horizontalInput, 0, verticalInput);
        Vector3 movementDirection = movementInput.normalized;

        charecterController.Move(movementDirection * playerSpeed * Time.deltaTime);

        if (movementDirection != Vector3.zero)
        {
            Quaternion desiredRotation = Quaternion.LookRotation(movementDirection, Vector3.up);
            transform.rotation = Quaternion.Slerp(transform.rotation, desiredRotation, rotationSpeed * Time.deltaTime);
        }
        if (Input.GetButtonDown("Jump") && groundedPlayer)
        {
            playerVelocity.y += Mathf.Sqrt(jumpHeight * -3f * gravityValue);
            animator.SetTrigger("Jumping");
        }

        playerVelocity.y += gravityValue * Time.deltaTime;
        charecterController.Move(playerVelocity * Time.deltaTime);

        animator.SetFloat("Speed", Mathf.Abs(movementDirection.x) + Mathf.Abs(movementDirection.z));
        animator.SetBool("Ground", charecterController.isGrounded);



    }
    private void OnTriggerEnter(Collider other)
    {
        if(other.CompareTag("Boxdamage"))
        {         
           isDead = true;
        }
    }
    
    void TogglerSlowMotion()
    {

        Time.timeScale = 0.5f;
    }
    IEnumerator delaySlow()
    {
        yield return new WaitForSeconds(2f);
        Time.timeScale = 1;
    }

    void fixGravityWhenPlayerDead()
    {
        playerVelocity.y += gravityValue * Time.deltaTime;
        charecterController.Move(playerVelocity * Time.deltaTime);
    }
    private void OnTriggerStay(Collider other)
    {
        if (other.CompareTag("Boxdamage") && PlayerController.instance.groundedPlayer)
        {
            isDead = true;
        }
    }
}
